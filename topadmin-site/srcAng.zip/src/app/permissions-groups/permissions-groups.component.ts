import { Component } from '@angular/core';
import { PermissionGroup, PermissionsGroupsService } from '../services/permissions-groups.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-permissions-groups',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './permissions-groups.component.html',
  styleUrl: './permissions-groups.component.css'
})
export class PermissionsGroupsComponent {
  permissionsGroups: PermissionGroup[] = [];
  isLoading = true;
  status = false;
  error = '';
  constructor(
    // private router: Router,
    private permissionGroupService: PermissionsGroupsService

  ) {

  }
  ngOnInit() {
    this.permissionGroupService.read().subscribe({
      next: (response) => {
        this.status = true;
        this.permissionsGroups = response
        console.log(response);

      },
      error: (err) => {
        this.error = err.error.message.ar
        this.status = false;
        this.isLoading = false;
        // this.permissionsService.deleteId()
        
      }
      ,
      complete: () => {
        this.isLoading = false;
        // this.permissionsService.deleteId()
      }
      
    })
  }
}
